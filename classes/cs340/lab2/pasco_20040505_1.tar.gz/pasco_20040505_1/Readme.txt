Enter the  "src" directory.  Type "make installwin" within Cygwin to
make Pasco for Windows.  Type "make install" to make Pasco for Unix.
The binaries will be located in the "bin" directory.

Keith J. Jones
keith.jones@foundstone.com