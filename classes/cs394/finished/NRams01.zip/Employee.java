/**
 * 
 */

/**
 * @author Oni
 *
 */
public class Employee extends Member {
	
	protected String department; int yearHired;

	/**
	 * Bullshit needed for serializable class in Java
	 */
	private static final long serialVersionUID = 9096089439257336418L;

	/**
	 * 
	 */
	public Employee() { }
	
	public Employee(int id) {
		super(id);
		// TODO Auto-generated constructor stub
	}
	
	public void generate() { 
	       generate(rnd.nextInt(999999999 - 10000000 + 1) + 10000000) ;
	}
	public void generate( int id )  {
		ID = id;
		fName = Names.firstName[rnd.nextInt(Names.firstName.length)];
		lName = Names.lastName[rnd.nextInt(Names.lastName.length)];
		department = Names.department[rnd.nextInt(Names.department.length)];
		yearHired = rnd.nextInt(2014 - 1965) + 1965;
	}
	
	public String toString(){
		String s = ID + ": " + fName + " " + lName + 
				" Department: " + department + " Year hired: " + yearHired;
		return s;
	}
	
	public String toString( boolean b ){
		String s = ID + ": " + 
				fName + " " + lName + 
				" Department: " + department + " Year hired: " + yearHired;
		if(!b){ s = ID + ": " + fName + " " + lName; }
		return s;
	}
	
	public int compareTo( Employee e ) {
	       return ID - e.ID;
   }
	
	public String toHTMLRow() { return "<tr>" + toHTMLCols() + "</tr>"; }
		  
	public String toHTMLCols( ) {
		return "<td>" + ScreenIO.formatSSN(ID) + "</td>" +
				"<td>" + fName + "</td>" +
				"<td>" + lName + "</td>" + 
				"<td>" + department + "</td>" +
				"<td>" + yearHired + "</td>";
	}
}
