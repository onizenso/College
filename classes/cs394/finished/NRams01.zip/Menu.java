import java.util.*;
import java.io.*;
import java.awt.Desktop;

public class Menu {

	static Scanner scan = new Scanner(System.in);
	static Random rnd = new Random();
	protected char choice; protected int ind = 0, cap = 1000;
	protected Vector<Member> vm = new Vector<Member>();
	protected Member [] am = new Member[cap];
	
	
	protected String menu = 
		"================ CS 394 Assignment 1 ===============	\n" +
		"G/g:   Ask for a N, and generate N members of mixed	\n" +
        		"\tMember class's objects, and store in a Vector	\n" + 
        		"\tand a array Objects.							\n\n" +

		"S/s/ : Sort the members in the vector and array in		\n" +
                "\tascending order.\n\n"+

		"V/v/ : Show the members in the vector and array .		\n\n" +

		"O/o/ : Save objects inside vector into a HTML file		\n" +
		       	"\twith objects saved in the format of HTML		\n" +
		       	"\tTable.\n\n" +
		
		"F/f  : Show HTML file contents on screen.				\n\n" +

		"L/l  : Launch the default internet browser to			\n" +
				"\tdisplay the generated HTML file.				\n\n" +
		"--------------------------------------------------		\n" +
		"H/h/?: Display this menu.								\n" +
		"E/e  : Exit											\n" +
		"=================================================		\n\n";
	
	public Menu() { }
	
	public void printMenu() { 
		System.out.print(menu);
		execMenu( scan.next().toCharArray()[0] );
	}
	
	public void execMenu( char c ) {
		switch(c){
			case 'G':
			case 'g':
				System.out.println("How many members would you like to make?");
				System.out.flush();
				mixGen( scan.nextInt() );
				break;
			case 'S':
			case 's':
				sort();
				break;
			case 'V':
			case 'v':
				printMembers();
				break;
			case 'O':
			case 'o':
				writeHTML();
				break;
			case 'F':
			case 'f':
				readHTML();
				break;
			case 'L':
			case 'l':
				openHTML();
			case 'E':
			case 'e':
				System.exit(0);
				break;
		}
		printMenu();
	}
	
	public void mixGen(int n) {
		int addm = ind + n;
		if(ind >= cap || addm >= cap) resize();
		for(int i = ind; i < addm; i++){ 
			switch( rnd.nextInt(4) ){
				case 0:
					Member m = new Member();
					vm.addElement( m );
					am[ind++] = m;
					break;
				case 1:
					Student s = new Student();
					vm.addElement( s );
					am[ind++] = s;
					break;
				case 2: 
					Employee e = new Employee();
					vm.addElement( e );
					am[ind++] = e;
					break;
				case 3:
					Faculty f = new Faculty();
					vm.addElement( f );
					am[ind++] = f;
					break;
				case 4:
					Staff t = new Staff();
					vm.addElement( t );
					am[ind++] = t;
					break;
				default:
					break;
			}
		}
	}
	
	protected void resize(){
		int rc = cap*2;
		Member[] t = new Member[rc];
		for( int i =0 ; i < cap ; i++ ){ t[i] = am[i]; }
		am = t; cap = rc;
	}
	
	public void sort(){
		if(vm.isEmpty() || am.length <= 1) return;
		quicksort(0, ind - 1);
	}
	  // Quicksort algorithm based on the tutorial by Lars Vogel
	  // http://www.vogella.com/tutorials/JavaAlgorithmsQuicksort/article.html
	  protected void quicksort(int low, int high) {
		    int i = low, j = high;
		    // Get the pivot element from the middle of the list
		    int mid = low + (high-low)/2;
	    Member pivot = am[mid];
	    
	
	    // Divide into two lists
	    while (i <= j) {
	      // Move left index closer to pivot if Member < pivot
	      while (am[i].compareTo(pivot) < 0) {
	        i++;
	      }
	      // Move right index closer to pivot if Member[j] > pivot
	      while (am[j].compareTo(pivot) > 0 ) {
	        j--;
	      }
	
	      // If we have found Member[j] > pivot and Member[i] < pivot, 
	      // then we exchange values.
	      if (i <= j) {
	        exchange(i, j);
	        i++;
	        j--;
	      }
	    }
	    // Recursion
	    if (low < j)
	      quicksort(low, j);
	    if (i < high)
	      quicksort(i, high);
	  }
	  
	  protected void exchange(int i, int j){
		  Member t = am[i], vi = vm.elementAt(i), vj = vm.elementAt(j);
		  am[i] = am[j]; am[j] = t;
		  vm.removeElement(vi);
		  vm.removeElement(vj);
		  vm.insertElementAt(vj, i); vm.insertElementAt(t, j);
	  }
	
	public void printMembers(){
		Iterator<Member> im = vm.iterator();
		
		System.out.println( "Member Vector: " );
		while( im.hasNext() ){ System.out.println( im.next().toString() ); }
		
		System.out.println("=============================================");
		
		System.out.println( "Member Array: " );
		for(int i = 0; i < ind; i++){ 
			System.out.println( am[i].toString() );
		}
	}
	
	public void openHTML(){
		File f = new File("member.html");
		try{ Desktop.getDesktop().browse(f.toURI()); } 
		catch(Exception x){ x.printStackTrace(); }
	}
	
	public void readHTML(){
		try{
			FileReader fr = new FileReader("member.html");
			BufferedReader br = new BufferedReader(fr);
			StringBuffer sb = new StringBuffer(); String s;
			
			while( ( s = br.readLine() ) != null ){ sb.append(s + "\n"); }
			
			System.out.println("Member File Contents:");
			System.out.println( sb.toString() );
			
			br.close();
			fr.close();
		} catch (IOException x){ x.printStackTrace(); }
	}
	
	public void writeHTML(){
		try{
			PrintWriter ps = new PrintWriter("member.html");
			ps.println("<hmtl><body><table width=50%>");
			ps.println("<tr><th>Member List</th></tr>");
			for(int i = 0 ; i < ind ; i++){
				ps.println(am[i].toHTMLRow());
			}
			ps.println("</table></body></html>");
			ps.flush();
			ps.close();
		} catch(Exception x){ x.printStackTrace(); }
	}
	
	public static void main(String[] args) {
		char c = '\0';
		Menu m = new Menu();
		
		System.out.println("Enter H/h/? to display the menu.");
		System.out.println("Enter E/e to exit.");
		System.out.flush();
		c = scan.next().toCharArray()[0];
		
		switch(c){
			case 'H':
			case 'h':
			case '?':
				m.printMenu();
				break;
			case 'E':
			case 'e':
				System.exit(0);
				break;
			default:
				break;
		}
	}

}
