/**
 * 
 */

/**
 * @author Oni
 *
 */
public class Student extends Member {
	
	protected String major; float GPA;

	/**
	 * Bullshit needed for serializable class in Java
	 */
	private static final long serialVersionUID = 9096089439257336418L;
	
	public Student() {
		// TODO Auto-generated constructor stub
	}
	
	public Student(int id) {
		super(id);
		// TODO Auto-generated constructor stub
	}
	
	public void generate() { 
	       generate(rnd.nextInt(999999999 - 10000000 + 1) + 10000000) ;
	}
	public void generate( int id )  {
		ID = id;
		fName = Names.firstName[rnd.nextInt(Names.firstName.length)];
		lName = Names.lastName[rnd.nextInt(Names.lastName.length)];
		major = Names.major[rnd.nextInt(Names.major.length)];
		GPA = rnd.nextFloat() * 4.0f;
	}
	
	public String toString(){
		String s = ID + ": " + fName + " " + lName + " GPA: " + GPA;
		return s;
	}
	
	public String toString( boolean b ){
		String s = ID + ": " + 
				fName + " " + lName + 
				" Major: " + major + " GPA: " + GPA;
		if(!b){ s = ID + ": " + fName + " " + lName; }
		return s;
	}
	
	public int compareTo( Student s ) {
	       return ID - s.ID;
   }
	
	public String toHTMLRow() {
		return "<tr>" + toHTMLCols() + "</tr>"; 
	}
		  
	public String toHTMLCols( ) {
		return "<td>" + ScreenIO.formatSSN(ID) + "</td>" +
				"<td>" + fName + "</td>" +
				"<td>" + lName + "</td>" + 
				"<td>" + major + "</td>" +
				"<td>" + GPA + "</td>";
	}
}
