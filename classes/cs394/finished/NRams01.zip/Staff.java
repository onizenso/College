/**
 * @author NicholasRamsey
 *
 */
public class Staff extends Employee {
	
	protected String jobTitle;

	/**
	 * Bullshit needed for serializable class in Java
	 */
	private static final long serialVersionUID = 9096089439257336418L;
	public Staff() { }
	
	public Staff(int id) {
		super(id);
		// TODO Auto-generated constructor stub
	}
	
	public void generate() { 
	       generate(rnd.nextInt(999999999 - 10000000 + 1) + 10000000) ;
	}
	public void generate( int id )  {
		ID = id;
		fName = Names.firstName[rnd.nextInt(Names.firstName.length)];
		lName = Names.lastName[rnd.nextInt(Names.lastName.length)];
		jobTitle = Names.skill[rnd.nextInt(Names.skill.length)];
	}
	
	public String toString(){
		return ID + ": " + fName + " " + lName + 
				" Title: " + jobTitle;
	}
	
	public String toString( boolean b ){
		String s = ID + ": " + 
				fName + " " + lName + 
				" Title: " + jobTitle;
		
		if(!b){ s = ID + ": " + fName + " " + lName; }
		
		return s;
	}
	
	public int compareTo( Staff s ) {
	       return ID - s.ID;
	}
	
	public String toHTMLRow() { return "<tr>" + toHTMLCols() + "</tr>"; }
		  
	public String toHTMLCols( ) {
		return "<td>" + ScreenIO.formatSSN(ID) + "</td>" +
				"<td>" + fName + "</td>" +
				"<td>" + lName + "</td>" + 
				"<td>" + jobTitle + "</td>";
	}
}
