/**
 * @author NicholasRamsey
 *
 */
public class Faculty extends Employee {
	
	protected String degree;

	/**
	 * Bullshit needed for serializable class in Java
	 */
	private static final long serialVersionUID = 9096089439257336418L;

	/**
	 * 
	 */
	public Faculty() { }
	
	public Faculty(int id) {
		super(id);
		// TODO Auto-generated constructor stub
	}
	
	public void generate() { 
	       generate(rnd.nextInt(999999999 - 10000000 + 1) + 10000000) ;
	}
	public void generate( int id )  {
		ID = id;
		fName = Names.firstName[rnd.nextInt(Names.firstName.length)];
		lName = Names.lastName[rnd.nextInt(Names.lastName.length)];
		degree = Names.degree[rnd.nextInt(Names.degree.length)];
	}
	
	public String toString(){
		String s = ID + ": " + fName + " " + lName + 
				" Degree: " + degree;
		return s;
	}
	
	public String toString( boolean b ){
		String s = ID + ": " + 
				fName + " " + lName + 
				" Degree: " + degree;
		
		if(!b){ s = ID + ": " + fName + " " + lName; }
		
		return s;
	}
	
	public int compareTo( Faculty f ) {
	       return ID - f.ID;
	}
	
	public String toHTMLRow() { return "<tr>" + toHTMLCols() + "</tr>"; }
		  
	public String toHTMLCols( ) {
		return "<td>" + ScreenIO.formatSSN(ID) + "</td>" +
				"<td>" + fName + "</td>" +
				"<td>" + lName + "</td>" + 
				"<td>" + degree + "</td>";
	}
}
