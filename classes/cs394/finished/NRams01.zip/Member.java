/** CS394: Homework 1
 * 
 */

import java.util.*;
import java.io.*;
public class Member implements Comparable<Member>,  Serializable  {
   /**
	 * 
	 */
private static final long serialVersionUID = 1L;
protected int ID = 0;
   protected String fName = null, lName = null;
   static Random rnd = new Random();

   public   void generate() { 
       generate(rnd.nextInt(999999999 - 10000000 + 1) + 10000000) ;
   }
   public   void generate( int id )  {
       ID = id;
       fName = Names.firstName[rnd.nextInt(Names.firstName.length)];
       lName = Names.lastName[rnd.nextInt(Names.lastName.length)];
   }

   public   int	hashCode() { return ID; }
   public   Member() { generate() ; }
   public   Member(int id) { generate(id) ; }

   public String toString(boolean  lab ) {
       return ( lab? "MEM " : "" ) + toString();
   }

   public String toString() {
       /*return String.format("%03d-%02d-%04d-%12s-%12s",
	       	             ID / 1000000,
			     ID % 1000000 / 10000,
			     ID % 10000,
			     lName, fName);
       */
       return ID + ": " + fName + " " + lName;
   }

   public String toString(int len) {
       /*return String.format("%03d-%02d-%04d-%12s-%12s",
	       	             ID / 1000000,
			     ID % 1000000 / 10000,
			     ID % 10000,
			     lName, fName).substring(0,len);
       */
       return (ID + ": " + fName + " " + lName).substring(0,len);
   }

   public int compareTo( Member m ) {
       return ID - m.ID;
   }

   public Member changeID ( int id) { ID = id; return this; }

   public String toHTMLRow() {
       return "<tr>" + toHTMLCols() + "</tr>"; 
   }
	  
   public String toHTMLCols( ) {
       return "<td>" + ScreenIO.formatSSN(ID) + "</td>" +
	   "<td>" + lName + "</td>" +
	   "<td>" + fName + "</td>";
   }
	  
}
