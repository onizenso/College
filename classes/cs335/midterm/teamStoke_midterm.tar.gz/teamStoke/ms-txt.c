#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <time.h>

//#define rndDbl() (double)rand()/(double)RAND_MAX
//#define rndInt() (int)RAND_MAX/(int)rand()

typedef struct t_grid {
    int status;
    int over;
    int taken;
    int winTrace;
    float color[4];
} Grid;

void initGrid();
void fillRand();
void beginSearch();
void checkWin(int, int, int);
int checkStart(int);
void printGrid(int);

Grid** grid;
int grid_dim;
int win=0, vGamesWon=0, hGamesWon=0, gamesPlayed=0;

int main(int argc, char* argv[])
{
    if (argc<2)
    {
        printf("Use: ./ms-txt <num>\n"); 
        exit(EXIT_FAILURE);
    }

    grid_dim = atoi(argv[1]);

    int sel;
    
    do
    {
        printf("\n\tGame of V's and H's\n");
        printf("=========================\n");
        printf("1. Play Game\n");
        printf("2. Show Score Card\n");
        printf("0. Exit\n");
        printf("=========================\n");
        printf("Enter Selection: ");
        scanf("%i", &sel);
        printf("\n");

        if (sel == 0)
        {
            printf("Thank you for playing!\n");
        }

        else if (sel == 1)
        {
            printf("Starting Game....\n\n");
            win=0;
            gamesPlayed++;
            initGrid(); //Initialize Grid
            fillRand(); //Fill the grid with random assortment of 'V' and 'H'
            beginSearch(); //Helper function to clean up main()
        }

        else if (sel == 2)
        {
	    printf("=========================\n");
	    printf("Games Played: %i\n", gamesPlayed);
	    printf("Games won by V: %i\n", vGamesWon);
	    printf("Games won by H: %i\n", hGamesWon);
	    printf("=========================\n");
        }

        else
        {
            printf("%d is not a valid menu item.\n", sel);
        }
        printf("\n");
    } while (sel != 0);
    return 0;
}

void initGrid()
{
    int g, i, j; //Loop counters for memory allocation/initialization
    
    //Allocate memory for grid, test to ensure allocation succeeded
    if((grid = (Grid**)malloc(grid_dim*sizeof(Grid**))) == (Grid**)NULL) 
    {printf("Memory error"); exit(EXIT_FAILURE);}
    
    for(g=0;g<grid_dim;g++)
    {
        if((grid[g] = (Grid*)malloc(grid_dim*sizeof(Grid))) == (Grid*)NULL) 
        {printf("Memory error"); exit(EXIT_FAILURE);}
    }
    
    for(i=0;i<grid_dim;i++)
        for(j=0;j<grid_dim;j++)
        {
            grid[i][j].status=0;
            grid[i][j].taken=0;
            grid[i][j].winTrace=0;
        }
}

void fillRand()
{
    srand(time(NULL));
    int i, j;
    for(i=0; i < grid_dim; i++)
        for(j=0; j < grid_dim; j++)
            grid[i][j].status = ((rand()%1000+1)%2==0) ? 1 : 2;
}

void printGrid(int player)
{
    int i, j;
    for(i=0; i < grid_dim; i++)
    {
        for(j=0; j < grid_dim; j++)
        {
            printf(" %i", grid[i][j].status);
            if(grid[i][j].status==player && grid[i][j].winTrace==1)
                printf("*");
            else
                printf(" ");
        }
        printf("\n");
    }
    printf("\n");

    return;
}

void beginSearch()
{
    int i=0, j=0, v=1, h=2;
    
    if((j=checkStart(v))!=-1) // Check first row for a V 
    {
        checkWin(i, j, v); //Check for whether V has
        if(win == 0)
        {
            printGrid(v);
            printf("You didn't win V.\n\n");
        }
    }
    else
    {
        printGrid(v);
        printf("You didn't win V.\n\n");
    }
   
    i=0; j=0;
    if((i=checkStart(h))!=-1) // Check first row for a V 
    {
        checkWin(i, j, h); //Check for whether V has
        if(win == 0)
        {
            printGrid(h);
            printf("You didn't win H.\n\n");
        }
    }
    else
    {
        printGrid(h);
        printf("You didn't win H.\n\n");
    }
 
    for(i=0;i<grid_dim;i++)
        free(grid[i]);
    free(grid);
    return;
}

int checkStart(int player)
{
    int i;
    if(player == 1) //Searching for vertical player in first row
    {
        for(i=0;i<grid_dim;i++)
            if(grid[0][i].status == player)
                return i; //Search starting from col 'i' in checkWin() 
    }
    if(player == 2) //Search for horizontal player in first col
    {
        for(i=0;i<grid_dim;i++)
            if(grid[i][0].status == player)
                return i; //Search starting from row 'i' in checkWin() 
    }
    return -1;
}

void checkWin(int row, int col, int player)
{
    int i;

    /* quit if winner found */
    if(win==1){ return; }

    /* quit if out of bounds */
    if((row<0 || row>=grid_dim) || (col<0 || col>=grid_dim)){ return; }

    /* quit if different player in current pos */
    if(grid[row][col].status!=player){ return; }

    /* quit if already traced */
    if(grid[row][col].winTrace == 1){ return; }

    /* mark current pos */
    grid[row][col].winTrace = 1;

    if(player==1)
    {
        /* win condition */
        if((row==grid_dim-1)
                && (grid[row][col].status==player)
                && (grid[row][col].winTrace==1))
        {
            win = 1;
	    vGamesWon++;
            printf("You won V!\n");
            printGrid(player);
            return;
        }

        //Check next row
        checkWin(row+1, col-1, player);
        checkWin(row+1, col, player);
        checkWin(row+1, col+1, player);

        //Check current row
        checkWin(row, col-1, player);
        checkWin(row, col+1, player);

        //Check previous row
        checkWin(row-1, col-1, player);
        checkWin(row-1, col, player);
        checkWin(row-1, col+1, player);


        //Check if any other player squares exist in the same row
        //that falls outside the bounds of the recursive check
        if(win==0 && grid[row][col].winTrace==1)
        {
            //Unmark square as part of winning path
            grid[row][col].winTrace=0;
            for(i=col+1;i < grid_dim; i++)
            {
                //Check for untraced player squares on same row
                //outside the 8-square bounds of the recursive function
                if(grid[row][i].status==player && grid[row][i].winTrace==0)
                {
                    checkWin(row, i, player);
                    return;
                }
                //Recursion on this element did not yield a win
                else if(i==(grid_dim-1))
                    return;
            }
        }
    }
    else if(player==2)
    {
        /* win condition */
        if((col==grid_dim-1)
                && (grid[row][col].status==player)
                && (grid[row][col].winTrace==1))
        {
            win = 1;
	    hGamesWon++;
            printf("You won H!\n");
            printGrid(player);
            return;
        }

        //Check next col 
        checkWin(row-1, col+1, player);
        checkWin(row, col+1, player);
        checkWin(row+1, col+1, player);

        //Check current col
        checkWin(row, col-1, player);
        checkWin(row, col+1, player);

        //Check previous col
        checkWin(row-1, col-1, player);
        checkWin(row, col-1, player);
        checkWin(row+1, col-1, player);


        //Check if any other player squares exist in the same row
        //that falls outside the bounds of the recursive check
        if(win==0 && grid[row][col].winTrace==1)
        {
            //Unmark square as part of winning path
            grid[row][col].winTrace=0; 
            for(i=row+1;i < grid_dim; i++)
            {
                //Check for untraced player squares on same column
                //outside the 8-square bounds of the recursive function
                if(grid[i][col].status==player && grid[i][col].winTrace==0)
                {
                    checkWin(i, col, player);
                    return;
                }
                //Recursion on this element did not yield a win
                else if(i==(grid_dim-1))
                    return;
            }
        }
    }
}
