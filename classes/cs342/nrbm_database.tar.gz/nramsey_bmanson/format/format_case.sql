COL caseid      HEADING 'CID'                      FORMAT 999999       
COL clientid    HEADING 'Client ID'                FORMAT 999999
COL sdate       WORD_WRAP HEADING 'sDate'          FORMAT A20
COL edate       WORD_WRAP HEADING 'eDate'          FORMAT A20
COL evidence    TRUNC HEADING 'Evidence'           FORMAT A20
COL category    WORD_WRAP HEADING 'Category'       FORMAT A10
COL litigation  WORD_WRAP HEADING 'Litigation'     FORMAT A15
COL notes       WORD_WRAP HEADING 'Notes'          FORMAT A10

