COL caid        HEADING 'CaID'              FORMAT 999999       
COL caseid      HEADING 'Case ID'           FORMAT 999999       
COL clientid    HEADING 'Client ID'         FORMAT 999999
COL lawid       HEADING 'Law ID'            FORMAT 999999       
COL adlawid     HEADING 'adLaw ID'          FORMAT 999999       
COL dateon      WORD_WRAP HEADING 'Date On' FORMAT A20
COL results     WORD_WRAP HEADING 'Results' FORMAT A20
 
