COL workid      HEADING 'Work ID'           FORMAT 999999       
COL staffid     HEADING 'Staff ID'          FORMAT 999999
COL lawid       HEADING 'Law ID'            FORMAT 999999
COL sdate       WORD_WRAP HEADING 'sDate'   FORMAT A20
COL edate       WORD_WRAP HEADING 'eDate'   FORMAT A20
COL salary      WORD_WRAP HEADING 'Salary'  FORMAT $999,999.90
COL hours       WORD_WRAP HEADING 'Hours'   FORMAT 999
   
