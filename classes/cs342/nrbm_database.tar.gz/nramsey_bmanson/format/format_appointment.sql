COL aptid                 HEADING 'AptID'       FORMAT 999999       
COL lawid                 HEADING 'LawID'       FORMAT 999999       
COL caseid                HEADING 'CaseID'      FORMAT 999999       
COL clientid              HEADING 'ClientID'    FORMAT 999999       
COL dateon      WORD_WRAP HEADING 'DateOn'      FORMAT A15
COL location    TRUNC     HEADING 'Location'    FORMAT A15
COL description TRUNC     HEADING 'Description' FORMAT A15

