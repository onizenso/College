COL setsid            HEADING 'SetsID'  FORMAT 999999       
COL staffid           HEADING 'StaffID' FORMAT 999999
COL aptid             HEADING 'AptID'   FORMAT 999999
COL dateset WORD_WRAP HEADING 'DateSet' FORMAT A20
 
