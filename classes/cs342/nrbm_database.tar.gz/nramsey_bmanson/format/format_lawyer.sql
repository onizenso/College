COL lawid              HEADING 'LID'        FORMAT 999999       
COL fname    WORD_WRAP HEADING 'First Name' FORMAT A15
COL lname    WORD_WRAP HEADING 'Last Name'  FORMAT A15
COL position WORD_WRAP HEADING 'Position'   FORMAT A15

