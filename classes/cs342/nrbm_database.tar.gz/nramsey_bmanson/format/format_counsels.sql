COL counselsid  HEADING 'Counsels ID'       FORMAT 999999       
COL lawid       HEADING 'Law ID'            FORMAT 999999
COL clientid    HEADING 'Client ID'         FORMAT 999999
COL sdate       WORD_WRAP HEADING 'sDate'   FORMAT A20
COL edate       WORD_WRAP HEADING 'eDate'   FORMAT A20
COL hours       WORD_WRAP HEADING 'Hours'   FORMAT 999
COL fees        WORD_WRAP HEADING 'Fees'    FORMAT A10
 
