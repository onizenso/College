COL setsid            HEADING 'SetsID'  FORMAT 999999       
COL staffid           HEADING 'StaffID' FORMAT 999999
COL sdate   WORD_WRAP HEADING 'SDate'   FORMAT A20
COL edate   WORD_WRAP HEADING 'EDate'   FORMAT A20
COL results TRUNC     HEADING 'EDate'   FORMAT A20
 
