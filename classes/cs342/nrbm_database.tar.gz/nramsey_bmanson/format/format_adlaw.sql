COL adlawid               HEADING 'adLaw ID'       FORMAT 999999       
COL fname       WORD_WRAP HEADING 'fName'          FORMAT A10
COL lName       WORD_WRAP HEADING 'lName'          FORMAT A10
COL address     TRUNCATED HEADING 'Address'        FORMAT A25
COL email       TRUNCATED HEADING 'Email'          FORMAT A25
COL phone       WORD_WRAP HEADING 'Phone'          FORMAT A15
