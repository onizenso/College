COL phoneid     HEADING 'Phone ID'  FORMAT 999999       
COL clientid    HEADING 'Client ID' FORMAT 999999
COL home        HEADING 'Home'      FORMAT A15
COL cell        HEADING 'Cell'      FORMAT A15
COL business    HEADING 'Business'  FORMAT A15
 
