-- Find hotel chain with exactly one room
-- Renames the output column for count
select hNo, count(*) "Hotel with room price > 1000"
from hotel h inner join room r on (h.hno = r.hno and r.price > 1000)
group by hNo
having count(*) = 1
/
