-- Find hotel chain with exactly one room

select hName, count(*) "Hotels with one room price > 1000" --Renames the output column for count
from hotel h, room r
where h.hno = r.hno and r.price > 1000
group by hName
having count(*) = 1
