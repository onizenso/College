

select unique h.hName
from hotel h
where not exists
        (select * from hotel c
        where not exists
            ( select * from hotel d
              where d.hName = h.hName and 
                    d.city = c.city
            )
        )
/
