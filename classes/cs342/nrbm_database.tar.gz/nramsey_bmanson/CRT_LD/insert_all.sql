alter session set nls_date_format='YYYY-MM-DD HH24:MI:SS';

@/home/cs342/nramsey_bmanson/CRT_LD/insert_adverseLawyer.sql
@/home/cs342/nramsey_bmanson/CRT_LD/insert_appointment.sql
@/home/cs342/nramsey_bmanson/CRT_LD/update_appointment.sql
@/home/cs342/nramsey_bmanson/CRT_LD/insert_case.sql
@/home/cs342/nramsey_bmanson/CRT_LD/insert_client.sql
@/home/cs342/nramsey_bmanson/CRT_LD/insert_counsels.sql
@/home/cs342/nramsey_bmanson/CRT_LD/insert_courtAppearance.sql
@/home/cs342/nramsey_bmanson/CRT_LD/insert_lawyer.sql
@/home/cs342/nramsey_bmanson/CRT_LD/insert_litigates.sql
@/home/cs342/nramsey_bmanson/CRT_LD/insert_phone.sql
@/home/cs342/nramsey_bmanson/CRT_LD/insert_sets.sql
@/home/cs342/nramsey_bmanson/CRT_LD/insert_staff.sql
@/home/cs342/nramsey_bmanson/CRT_LD/insert_worksFor.sql
