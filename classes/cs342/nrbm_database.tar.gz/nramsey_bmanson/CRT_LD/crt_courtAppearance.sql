CREATE TABLE NRBM_CourtAppearance(
  caID number primary key,
  caseID number,
  clientID number,
  lawID number,
  adLawID number,
  dateOn Date default NULL,
  results varchar2(255) default NULL
--CONSTRAINT fk_courtAppearance_case    FOREIGN KEY(caseID)     REFERENCES NRBM_Case(caseID),
--CONSTRAINT fk_courtAppearance_client  FOREIGN KEY(clientID)   REFERENCES NRBM_Client(clientID),
--CONSTRAINT fk_courtAppearance_lawyer  FOREIGN KEY(lawID)      REFERENCES NRBM_Lawyer(lawID),
--CONSTRAINT fk_courtAppearance_adlaw   FOREIGN KEY(adLawID)    REFERENCES NRBM_AdverseLawyer(adLawID),
);
