create sequence seq_litigates
    start with 1
    increment by 1;
 
