create sequence seq_adverseLawyer
    start with 1
    increment by 1;
 
