create sequence seq_staff
    start with 1
    increment by 1;
 
