create sequence seq_counsels
    start with 1
    increment by 1;
 
