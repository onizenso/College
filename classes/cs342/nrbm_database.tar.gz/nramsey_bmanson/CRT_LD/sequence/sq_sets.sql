create sequence seq_sets
    start with 1
    increment by 1;
 
