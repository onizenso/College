create sequence seq_appointment
    start with 1
    increment by 1;
 
