create sequence seq_phone
    start with 1
    increment by 1;
 
