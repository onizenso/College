create sequence seq_case
    start with 1
    increment by 1;
 
