create sequence seq_worksFor
    start with 1
    increment by 1;
 
