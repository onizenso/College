create sequence seq_client
    start with 1
    increment by 1;
 
