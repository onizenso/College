create sequence seq_lawyer
    start with 1
    increment by 1;
 
