create sequence seq_courtAppearance
    start with 1
    increment by 1;
 
