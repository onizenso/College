DROP TABLE NRBM_CourtAppearance;

