CREATE TABLE NRBM_Litigates(
  litID number primary key,
  adLawID number,
  caseID number,
  sDate Date default NULL,
  eDate Date default NULL,
  results varchar2(255) default NULL
--CONSTRAINT fk_litigates_adLaw FOREIGN KEY (adLawID)   REFERENCES NRBM_AdverseLawyer(adLawID),
--CONSTRAINT fk_litigates_case  FOREIGN KEY (caseID)    REFERENCES NRBM_Case(caseID)
);
