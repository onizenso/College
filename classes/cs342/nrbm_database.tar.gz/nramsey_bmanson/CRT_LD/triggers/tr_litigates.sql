create trigger tr_litigates               
before insert on NRBM_Litigates
for each row
begin
    select seq_litigates.nextval into :new.litID from dual;
end;
/
