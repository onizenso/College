create trigger tr_lawyer               
before insert on NRBM_Lawyer
for each row
begin
    select seq_lawyer.nextval into :new.lawID from dual;
end;
/
