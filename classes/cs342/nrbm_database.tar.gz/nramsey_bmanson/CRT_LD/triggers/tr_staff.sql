create trigger tr_staff               
before insert on NRBM_Staff
for each row
begin
    select seq_staff.nextval into :new.staffID from dual;
end;
/
