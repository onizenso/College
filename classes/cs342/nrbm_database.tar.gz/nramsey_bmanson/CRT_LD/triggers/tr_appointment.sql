create trigger tr_appointment              
before insert on NRBM_Appointment
for each row
begin
    select seq_appointment.nextval into :new.aptID from dual;
end;
/
