create trigger tr_courtAppearance               
before insert on NRBM_CourtAppearance
for each row
begin
    select seq_courtAppearance.nextval into :new.caID from dual;
end;
/
