create trigger tr_adverseLawyer               
before insert on NRBM_AdverseLawyer
for each row
begin
    select seq_adverseLawyer.nextval into :new.adLawID from dual;
end;
/
