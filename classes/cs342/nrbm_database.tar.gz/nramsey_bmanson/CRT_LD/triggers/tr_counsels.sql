create trigger tr_counsels               
before insert on NRBM_Counsels
for each row
begin
    select seq_counsels.nextval into :new.counselsID from dual;
end;
/
