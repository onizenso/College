create trigger tr_client               
before insert on NRBM_Client
for each row
begin
    select seq_client.nextval into :new.clientID from dual;
end;
/
