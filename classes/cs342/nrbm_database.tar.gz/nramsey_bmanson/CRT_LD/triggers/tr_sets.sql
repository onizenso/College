create trigger tr_sets               
before insert on NRBM_Sets
for each row
begin
    select seq_sets.nextval into :new.setsID from dual;
end;
/
