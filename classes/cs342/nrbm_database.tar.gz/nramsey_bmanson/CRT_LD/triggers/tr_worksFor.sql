create trigger tr_worksFor               
before insert on NRBM_WorksFor
for each row
begin
    select seq_worksFor.nextval into :new.workID from dual;
end;
/
