create trigger tr_phone               
before insert on NRBM_Phone
for each row
begin
    select seq_phone.nextval into :new.phoneID from dual;
end;
/
