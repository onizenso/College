create trigger tr_case             
before insert on NRBM_Case
for each row
begin
    select seq_case.nextval into :new.caseID from dual;
end;
/
