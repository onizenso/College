INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (25,5,'1993-11-22 10:37:21','1995-06-02 04:10:34',106,'195.87/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (12,10,'1989-05-14 12:04:49','2013-06-17 20:49:26',158,'137.81/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (13,27,'2006-08-03 08:26:36','1987-09-02 23:09:11',146,'101.17/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (22,30,'1986-01-04 01:50:14','1987-11-24 02:17:41',145,'191.29/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (25,8,'1992-07-24 12:04:11','1987-10-26 21:43:22',149,'164.61/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (18,8,'2000-06-03 02:02:50','2008-01-18 02:40:27',72,'190.90/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (27,6,'1987-07-22 08:39:40','1997-07-08 09:53:11',70,'101.87/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (26,27,'2008-03-15 00:31:25','2013-04-15 10:29:50',127,'156.11/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (17,27,'1995-05-04 04:34:33','2011-07-22 02:46:23',141,'142.69/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (1,18,'2006-06-12 10:25:18','1997-01-27 20:44:54',134,'155.00/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (4,13,'2004-08-25 06:41:52','1992-07-22 00:50:13',153,'175.57/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (22,24,'2006-11-28 09:03:44','2012-05-24 17:26:50',58,'151.88/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (22,7,'2005-08-01 01:47:55','1987-05-15 01:14:25',43,'165.25/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (19,29,'1995-10-01 20:55:14','1994-04-06 10:11:20',39,'143.25/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (15,23,'1995-01-23 17:05:11','1990-12-21 01:28:35',74,'152.65/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (13,11,'1988-06-15 01:30:11','2010-08-01 05:42:42',109,'145.37/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (24,7,'1995-05-04 15:47:02','1996-03-23 00:29:03',133,'157.44/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (5,2,'2006-05-22 22:37:55','1995-03-26 16:52:48',116,'179.33/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (28,19,'2009-01-23 03:11:14','2001-11-17 17:37:23',98,'175.84/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (23,19,'2003-08-12 13:26:25','2009-02-15 00:48:35',40,'162.78/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (18,23,'2001-07-22 07:29:02','1986-06-08 04:47:31',99,'154.76/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (16,14,'2007-12-10 23:33:23','2005-10-18 06:19:29',69,'195.08/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (24,5,'1992-06-27 21:32:36','1987-10-03 15:58:35',100,'163.71/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (30,23,'1987-11-21 14:22:19','1995-04-09 08:24:55',93,'168.80/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (4,8,'1992-07-08 14:59:04','1995-04-23 13:07:59',59,'133.59/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (15,20,'1994-02-10 03:19:27','1993-11-01 03:07:51',107,'190.00/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (4,14,'2011-07-02 20:36:18','2000-04-04 00:43:30',138,'135.46/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (28,18,'2002-05-15 10:00:51','2006-11-02 09:10:50',147,'119.15/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (19,15,'2002-08-20 11:01:28','1989-11-18 03:20:39',91,'120.34/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (6,8,'1990-06-17 03:47:20','2009-11-08 09:09:05',39,'160.93/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (10,25,'2012-12-25 01:52:55','1997-08-23 16:11:15',142,'135.55/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (27,11,'1998-03-05 21:20:05','1990-04-28 13:04:37',65,'192.70/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (8,5,'2006-02-16 21:52:22','1988-05-31 17:28:32',88,'145.59/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (25,4,'2012-03-14 00:35:41','1987-08-10 15:47:13',55,'191.30/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (10,7,'1987-12-24 15:19:14','1987-10-19 01:45:36',91,'141.15/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (19,22,'1997-12-27 13:23:12','2008-11-19 12:26:12',44,'176.13/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (7,25,'2010-11-16 07:25:07','1989-02-09 11:01:22',107,'143.69/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (2,23,'1999-03-17 14:12:27','2000-11-05 18:36:55',49,'196.53/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (30,12,'1999-02-06 15:55:04','1998-07-15 08:02:28',118,'111.21/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (15,17,'1997-03-29 17:05:55','1991-04-04 09:46:23',154,'162.59/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (19,27,'1996-03-28 16:59:00','2008-03-15 23:46:37',130,'180.82/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (15,23,'1996-11-14 14:50:46','1987-09-29 11:31:22',38,'147.30/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (25,30,'1996-11-17 03:05:56','2005-06-14 09:10:53',58,'139.54/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (9,24,'1989-11-18 23:52:07','2003-10-07 06:41:06',74,'191.33/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (17,4,'1996-05-23 04:39:49','2001-03-05 05:30:44',105,'188.96/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (2,23,'1994-04-06 04:36:07','2001-12-16 22:29:09',64,'142.76/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (7,29,'1993-09-19 21:43:45','1992-12-24 22:40:27',40,'125.94/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (26,1,'2011-07-12 16:55:47','2009-01-01 00:05:35',147,'131.26/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (2,1,'1987-12-04 08:07:25','1994-06-18 18:06:35',59,'133.57/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (23,15,'2009-03-05 15:00:47','2009-12-06 19:30:34',136,'105.20/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (22,3,'2002-11-07 22:41:45','1999-04-03 14:29:48',119,'105.22/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (15,18,'1988-05-13 00:26:00','1996-01-23 19:31:16',84,'160.14/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (19,12,'2013-01-17 00:05:06','1996-02-27 04:34:10',83,'101.45/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (27,21,'2012-07-28 20:44:25','2009-05-02 01:34:46',54,'109.30/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (9,7,'1994-12-27 16:28:22','1986-02-28 00:19:21',73,'147.32/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (27,8,'1994-06-03 03:02:21','1997-03-09 06:23:28',36,'143.68/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (7,15,'1993-10-04 01:14:31','1998-02-24 09:46:07',31,'169.45/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (11,10,'1996-12-09 19:53:39','2000-03-30 10:40:29',35,'149.00/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (8,12,'1996-08-15 23:36:39','1997-06-13 08:29:07',35,'166.24/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (16,5,'2012-07-20 01:29:46','2002-08-28 09:08:43',102,'154.04/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (11,26,'1999-02-07 13:45:34','1992-07-21 16:41:51',114,'116.14/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (2,10,'2012-05-08 18:30:34','2007-04-27 00:36:37',53,'178.63/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (16,29,'1993-03-25 18:26:27','2005-04-02 17:22:07',106,'132.90/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (29,26,'2001-01-07 17:53:21','1993-06-28 02:26:10',60,'124.90/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (7,4,'2000-11-06 17:32:36','2003-08-07 08:11:31',90,'101.65/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (18,1,'1997-01-22 15:08:35','1989-02-09 05:42:04',127,'142.60/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (22,7,'1992-11-26 07:34:52','1987-06-02 00:41:12',55,'192.27/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (24,17,'1994-07-12 00:04:46','1990-08-26 04:56:39',101,'193.30/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (27,25,'1997-10-05 01:08:47','2009-05-15 14:22:00',155,'158.70/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (1,10,'2006-01-07 12:35:18','2000-02-21 13:27:19',33,'108.74/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (18,21,'1990-01-15 16:04:36','2000-09-02 15:13:26',152,'105.34/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (8,23,'2005-07-25 07:54:17','1988-12-26 05:25:02',57,'133.90/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (16,8,'2009-07-23 14:43:19','1988-08-26 03:46:49',50,'167.97/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (4,7,'1998-08-19 10:22:33','2012-11-08 17:59:06',29,'108.94/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (13,13,'1997-05-03 07:43:25','1999-10-02 01:44:15',47,'103.37/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (28,1,'1996-01-16 18:50:48','1998-11-03 15:09:58',49,'135.67/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (21,22,'1994-10-03 21:11:59','2008-08-15 21:37:02',80,'155.29/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (28,16,'2006-09-02 12:18:39','2011-06-14 22:31:47',159,'102.87/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (15,12,'2010-04-11 17:55:24','1999-09-29 04:47:43',132,'147.35/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (14,13,'1991-08-15 22:28:46','1998-11-13 09:50:32',38,'198.44/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (17,30,'1994-02-07 18:09:23','2002-09-17 00:43:10',135,'159.65/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (15,8,'1996-12-18 08:25:44','1990-12-05 18:39:37',98,'102.85/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (23,23,'2001-11-08 14:37:36','2011-06-12 01:49:17',135,'189.46/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (30,27,'1998-11-16 12:04:22','2007-05-29 04:18:45',25,'135.48/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (2,9,'1998-01-15 18:54:50','1994-11-03 01:22:58',86,'118.45/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (7,7,'1990-12-03 01:19:15','2008-12-08 21:18:06',89,'159.91/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (14,27,'1994-12-17 21:04:11','1990-11-27 11:10:34',50,'165.97/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (27,24,'1990-09-12 08:34:49','2005-06-01 23:36:54',121,'159.24/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (26,9,'2004-06-10 03:43:12','2000-10-29 16:19:33',37,'101.34/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (20,23,'2002-10-04 07:00:07','2013-08-24 14:04:28',93,'127.00/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (24,9,'1996-02-24 19:50:49','1991-05-12 17:23:24',92,'187.02/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (19,24,'1996-04-05 05:03:10','2012-03-30 05:37:51',129,'154.22/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (5,17,'2008-02-16 16:17:10','2011-05-19 06:00:16',96,'142.42/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (30,16,'1994-11-10 19:15:52','2012-05-29 23:31:41',80,'130.61/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (1,17,'2002-07-14 03:42:05','1991-04-09 09:36:13',121,'193.17/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (15,24,'2012-03-20 00:21:25','2003-07-28 23:51:16',150,'156.98/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (30,7,'1998-05-11 12:20:00','1988-09-05 23:20:21',132,'193.34/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (7,3,'1990-07-27 07:23:17','2007-01-18 14:50:35',104,'198.12/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (28,29,'1995-03-26 14:52:35','2004-07-28 01:13:52',145,'140.56/hr');
INSERT INTO NRBM_Counsels (lawID,clientID,sDate,eDate,hours,fees) VALUES (2,19,'1997-06-05 17:50:49','1997-03-16 08:55:18',110,'132.05/hr');































































































