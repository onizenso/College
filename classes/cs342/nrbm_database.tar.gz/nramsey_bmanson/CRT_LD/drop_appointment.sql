DROP TABLE NRBM_Appointment;
