CREATE TABLE NRBM_Phone (
  phoneID number primary key,
  clientID number,
  home varchar2(100) default NULL,
  cell varchar2(100) default NULL,
  business varchar2(100) default NULL
);
