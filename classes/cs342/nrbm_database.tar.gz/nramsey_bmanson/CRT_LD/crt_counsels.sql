CREATE TABLE NRBM_Counsels(
  counselsID number primary key,
  lawID number,
  clientID number,
  sDate varchar2(100) default NULL,
  eDate varchar2(100) default NULL,
  hours number default NULL,
  fees varchar2(100) default NULL
--CONSTRAINT fk_counsels_lawyer FOREIGN KEY(lawID)      REFERENCES NRBM_Lawyer (lawID),
--CONSTRAINT fk_counsels_client FOREIGN KEY(clientID)   REFERENCES NRBM_Client (clientID)
);
