CREATE TABLE NRBM_WorksFor (
  workID number primary key,
  staffID number,
  lawID number,
  sDate Date default NULL,
  eDate Date default NULL,
  salary number default NULL,
  hours number default NULL
);
--CONSTRAINT fk_worksfor_staff  FOREIGN KEY(staffID)    REFERENCES NRBM_Staff(staffID),
--CONSTRAINT fk_worksfor_lawyer FOREIGN KEY(lawID)      REFERENCES NRBM_Lawyer(lawID)

