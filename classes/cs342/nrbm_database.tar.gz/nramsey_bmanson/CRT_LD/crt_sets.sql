CREATE TABLE NRBM_Sets (
  setsID number primary key,
  staffID number,
  aptID number,
  dateSet Date default NULL
);
--CONSTRAINT fk_sets_staff        FOREIGN KEY(staffID)    REFERENCES NRBM_Staff(staffID),
--CONSTRAINT fk_sets_appointment  FOREIGN KEY(aptID)      REFERENCES NRBM_Appointment(aptID)
