ALTER TABLE Counsels
  RENAME TO NRBM_Counsels;
