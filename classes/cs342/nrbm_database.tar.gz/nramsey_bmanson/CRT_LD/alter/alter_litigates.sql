ALTER TABLE Litigates
  RENAME TO NRBM_Litigates;
