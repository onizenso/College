ALTER TABLE AdverseLawyer
  RENAME TO NRBM_AdverseLawyer;
