ALTER TABLE CourtAppearance
  RENAME TO NRBM_CourtAppearance;
