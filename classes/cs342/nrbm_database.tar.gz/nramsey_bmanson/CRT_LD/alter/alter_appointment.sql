ALTER TABLE Appointment
  RENAME TO NRBM_Appointment;
