DROP TABLE NRBM_AdverseLawyer;
