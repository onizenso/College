@/home/cs342/nramsey_bmanson/CRT_LD/drop_tables.sql
@/home/cs342/nramsey_bmanson/CRT_LD/drop_sequences.sql

@/home/cs342/nramsey_bmanson/CRT_LD/crt_tables.sql
@/home/cs342/nramsey_bmanson/CRT_LD/crt_sequences.sql
@/home/cs342/nramsey_bmanson/CRT_LD/crt_triggers.sql
@/home/cs342/nramsey_bmanson/CRT_LD/insert_all.sql

@/home/cs342/nramsey_bmanson/format/format_master.sql
