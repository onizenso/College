CREATE TABLE NRBM_Case (
  caseID number primary key,
  clientID number,
  sDate Date,
  eDate Date,
  evidence varchar2(255) default NULL,
  category varchar2(4000) default NULL,
  litigation varchar2(4000) default NULL,
  notes varchar2(4000) default NULL
--CONSTRAINT fk_case_client FOREIGN KEY(clientID) REFERENCES NRBM_Client (clientID)
);
