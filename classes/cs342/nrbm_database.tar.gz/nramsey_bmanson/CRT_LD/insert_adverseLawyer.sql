INSERT INTO NRBM_AdverseLawyer (fName,lName,address,email,phone) 
VALUES ('Aristotle','Stanley','491-1247 Neque. Avenue','nunc.sed.pede@non.co.uk','(661) 373-3900');
INSERT INTO NRBM_AdverseLawyer (fName,lName,address,email,phone) 
VALUES ('Hunter','Weber','P.O. Box 5 1603 Vestibulum Road','fringilla@nonlorem.net','(661) 923-8512');
INSERT INTO NRBM_AdverseLawyer (fName,lName,address,email,phone) 
VALUES ('Unity','Warner','145-8847 Sit St.','ac.turpis.egestas@diamnunc.edu','(559) 406-6979');
INSERT INTO NRBM_AdverseLawyer (fName,lName,address,email,phone) 
VALUES ('Petra','Bowman','P.O. Box 6 9962 Pretium Avenue','dapibus@egestas.net','(559) 169-6093');
INSERT INTO NRBM_AdverseLawyer (fName,lName,address,email,phone) 
VALUES ('Susan','Best','6865 Orci Av.','congue.turpis@miAliquamgravida.net','(661) 987-0685');
INSERT INTO NRBM_AdverseLawyer (fName,lName,address,email,phone) 
VALUES ('Brendan','Clemons','2294 Dui, Road','est.Nunc@pede.edu','(559) 578-4314');
INSERT INTO NRBM_AdverseLawyer (fName,lName,address,email,phone) 
VALUES ('Mohammad','Wiley','416-365 Ornare. Av.','consectetuer.adipiscing.elit@adipiscingfringillaporttitor.com','(661) 396-3361');
INSERT INTO NRBM_AdverseLawyer (fName,lName,address,email,phone) 
VALUES ('Xander','Branch','8065 Lorem. Ave','dui.augue.eu@libero.ca','(661) 905-8377');
INSERT INTO NRBM_AdverseLawyer (fName,lName,address,email,phone) 
VALUES ('Uta','Albert','922-9448 Lobortis Av.','convallis@purusaccumsaninterdum.ca','(559) 922-6248');
INSERT INTO NRBM_AdverseLawyer (fName,lName,address,email,phone) 
VALUES ('Shafira','Pace','Ap #985-920 Nec, St.','dui.semper@Crasvehiculaaliquet.ca','(661) 615-1470');
INSERT INTO NRBM_AdverseLawyer (fName,lName,address,email,phone) 
VALUES ('Keane','Potter','Ap #840-4237 Sit Road','adipiscing.non.luctus@Duisa.co.uk','(661) 773-2448');
INSERT INTO NRBM_AdverseLawyer (fName,lName,address,email,phone) 
VALUES ('Wing','Sawyer','450-4133 Venenatis Street','gravida.mauris.ut@ut.net','(559) 663-4239');
INSERT INTO NRBM_AdverseLawyer (fName,lName,address,email,phone) 
VALUES ('Porter','Farley','P.O. Box 3 8058 Sodales St.','id.sapien@lectus.org','(559) 456-3227');
INSERT INTO NRBM_AdverseLawyer (fName,lName,address,email,phone) 
VALUES ('Lars','Bonner','9428 Fringilla Rd.','consectetuer.adipiscing.elit@suscipit.net','(559) 996-1307');
INSERT INTO NRBM_AdverseLawyer (fName,lName,address,email,phone) 
VALUES ('Harding','Wilcox','Ap #831-2148 Amet St.','Morbi@lobortis.com','(559) 759-5491');
INSERT INTO NRBM_AdverseLawyer (fName,lName,address,email,phone) 
VALUES ('Emi','Clements','Ap #398-4791 Diam. Street','in.dolor.Fusce@et.com','(661) 695-7902');
INSERT INTO NRBM_AdverseLawyer (fName,lName,address,email,phone) 
VALUES ('Lara','Marsh','7554 Nam St.','amet.risus@commodo.ca','(559) 728-7468');
INSERT INTO NRBM_AdverseLawyer (fName,lName,address,email,phone) 
VALUES ('Daquan','Rios','P.O. Box 6 4059 Facilisis Av.','porta.elit.a@gravida.org','(559) 732-5043');
INSERT INTO NRBM_AdverseLawyer (fName,lName,address,email,phone) 
VALUES ('Stuart','Wolfe','P.O. Box 5 8962 Neque. Av.','Donec@accumsanconvallis.org','(559) 161-8450');
INSERT INTO NRBM_AdverseLawyer (fName,lName,address,email,phone) 
VALUES ('Maite','Hunt','387-1802 Pharetra. Rd.','dapibus@turpisegestas.ca','(559) 786-7829');
INSERT INTO NRBM_AdverseLawyer (fName,lName,address,email,phone) 
VALUES ('Nevada','James','P.O. Box 2 150 Dignissim Ave','enim.gravida@vel.net','(559) 533-3919');
INSERT INTO NRBM_AdverseLawyer (fName,lName,address,email,phone) 
VALUES ('Ayanna','Decker','1362 Fermentum Ave','facilisis.facilisis@placerat.ca','(661) 819-5879');
INSERT INTO NRBM_AdverseLawyer (fName,lName,address,email,phone) 
VALUES ('Jolene','English','4321 Nullam Road','venenatis.lacus@cursus.net','(559) 734-5207');
INSERT INTO NRBM_AdverseLawyer (fName,lName,address,email,phone) 
VALUES ('Zane','Mcmahon','Ap #613-5334 Aliquam Street','nisl@nisiCum.ca','(661) 272-9449');
INSERT INTO NRBM_AdverseLawyer (fName,lName,address,email,phone) 
VALUES ('Hamish','Pitts','Ap #880-3708 Class Street','Duis.cursus.diam@etrutrumeu.net','(661) 902-5298');
INSERT INTO NRBM_AdverseLawyer (fName,lName,address,email,phone) 
VALUES ('Hilary','Bender','888-1347 Cursus Av.','dictum.magna.Ut@odioNaminterdum.ca','(559) 534-3585');
INSERT INTO NRBM_AdverseLawyer (fName,lName,address,email,phone) 
VALUES ('Willa','Beach','694-5430 Magna Road','sit@ametfaucibus.net','(559) 487-8403');
INSERT INTO NRBM_AdverseLawyer (fName,lName,address,email,phone) 
VALUES ('Leslie','Cortez','P.O. Box 4 8550 Sodales Street','Aliquam.fringilla@Aeneaneget.com','(661) 656-4503');
INSERT INTO NRBM_AdverseLawyer (fName,lName,address,email,phone) 
VALUES ('Keith','Mckee','P.O. Box 9 6346 Auctor, Street','dui.Cras@justo.ca','(559) 877-1884');
INSERT INTO NRBM_AdverseLawyer (fName,lName,address,email,phone) 
VALUES ('Gareth','Mason','P.O. Box 7 4693 Proin Ave','semper.erat@atlacus.org','(559) 981-6794');
