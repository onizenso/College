SELECT DISTINCT c.fname, c.lname 
FROM nrbm_client c JOIN nrbm_counsels d
ON c.clientid = d.clientid 
AND d.hours > 40;
