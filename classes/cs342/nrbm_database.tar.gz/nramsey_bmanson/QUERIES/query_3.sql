SELECT DISTINCT a.location, a.description, a.dateon AS "Apt. Date"
FROM NRBM_Appointment a
WHERE EXISTS
    (SELECT c.clientID, l.lawID
        FROM NRBM_Client c, NRBM_Lawyer l
           WHERE 
                a.clientID = c.clientID AND
                a.lawID = l.lawID AND
                l.fName = 'Brooke' AND
                l.lName = 'Burnett' AND
                c.fName = 'Olga' AND
                c.lName = 'Navarro' 
            )
;

COL 'Apt. Date' HEADING 'Apt. Date' FORMAT A20;
--Brooke Burnett = lawyer 10
--Olga Navarro = client 29

--Select all appointments between Olga Navarro and Brooke Burnett.
