SELECT s.fname AS "First Name", s.lname AS "Last Name"
FROM (NRBM_Staff s JOIN NRBM_WorksFor w ON w.staffid = s.staffid) 
JOIN NRBM_Lawyer l ON w.lawid = l.lawid
WHERE l.fname='Felicia' AND l.lname='Crane';

COL 'First Name' HEADING 'First Name' FORMAT A15;
COL 'Last Name'  HEADING 'Last Name'  FORMAT A15;
