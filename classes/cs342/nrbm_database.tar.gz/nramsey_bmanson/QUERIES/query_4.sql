SELECT DISTINCT s.fName AS "First Name", 
                s.lName AS "Last Name", 
                maxsalary.salary
FROM NRBM_Staff s,
        (SELECT w.staffID AS staffID, w.salary AS salary 
            FROM NRBM_WorksFor w
            WHERE NOT EXISTS 
                (SELECT y.workid FROM NRBM_WorksFor x, NRBM_WorksFor y
                    WHERE y.salary < x.salary 
                    AND y.workid = w.workid) ) maxsalary
WHERE s.staffID = maxsalary.staffID;

COL 'First Name' HEADING 'First Name' FORMAT A15;
COL 'Last Name'  HEADING 'Last Name'  FORMAT A15;

