SELECT UNIQUE c.fname, c.lname 
FROM (nrbm_client c JOIN nrbm_courtAppearance ca ON ca.clientid = c.clientid)
JOIN nrbm_appointment a ON a.clientid = c.clientid
