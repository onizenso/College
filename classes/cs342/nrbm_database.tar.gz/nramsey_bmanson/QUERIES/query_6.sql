SELECT DISTINCT a.*
FROM NRBM_Appointment a
WHERE 
                a.location = 'CSUB' AND
                a.dateOn < '2004-12-01 00:00:00' AND
                a.dateOn > '2004-09-01 00:00:00';
--Select all appointments at 5274 Sem St. between October and November 2004.
