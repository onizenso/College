
select unique clientID
from NRBM_CLIENT c
where not exists
        (select * from NRBM_CLIENT d
        where not exists
            ( select * from NRBM_CLIENT e
              where e.fName = c.fName and 
                    e.lName = d.lName
            )
        )
/
