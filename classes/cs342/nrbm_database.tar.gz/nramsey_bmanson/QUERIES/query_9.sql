SELECT DISTINCT a.fname, a.lname, c.sdate, c.edate, c.category, c.litigation
FROM (nrbm_case c JOIN nrbm_litigates l
ON l.caseid = c.caseid)
JOIN nrbm_adverseLawyer a 
ON (l.adlawid = a.adlawid AND l.caseid = c.caseid);
