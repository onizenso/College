SELECT UNIQUE c.fname, c.lname FROM nrbm_client c 
WHERE
    NOT EXISTS
        (SELECT cl.clientid FROM nrbm_client cl JOIN nrbm_courtAppearance ca 
            ON cl.clientid = ca.clientid WHERE cl.clientid = c.clientid)
;
