SELECT DISTINCT cl.fname, cl.lname 
FROM NRBM_Client cl
WHERE EXISTS
    (SELECT f.clientid 
        FROM NRBM_Case d, NRBM_Case e, NRBM_Counsels f, NRBM_Lawyer g
        WHERE d.caseid != e.caseid AND d.clientid = e.clientid
            AND f.clientid = d.clientid AND f.lawid = g.lawid 
            AND g.fname = 'Grant' AND g.lname = 'Burton'
            AND f.clientid = cl.clientid
        )
;
