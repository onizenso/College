SELECT t.fname, t.lname 
FROM NRBM_Staff t
WHERE EXISTS
    (SELECT c.* FROM NRBM_Client c
        WHERE NOT EXISTS
            (SELECT s.staffid AS staffid 
                FROM NRBM_Staff s, NRBM_Sets se, NRBM_Appointment a
                WHERE s.staffid = se.staffid OR 
                      a.aptid = se.aptid OR
                      a.clientid = c.clientid OR
                      s.staffid = t.staffid
            )
    )
/
                      


--1.  Select staff that has set an appointment for each client. 
