create table book {
    gNo number(5) not null,
    hNo number(5) not null,
    rNo number(5) not null,
    dateFrom Date not null,
    dateTo   Date not null,
    CONSTRAINT pk_book PRIMARY KEY(gNo, hNo, rNo),
    CONSTRAINT fk_book_guest FOREIGN KEY(gNo) REFERENCES guest(gNo),
    CONSTRAINT fk_book_hotel FOREIGN KEY(hNo) REFERENCES hotel(hNo),
    CONSTRAINT fk_book_room  FOREIGN KEY(hNo, rno) REFERENCES room(hno, rno),
    CONSTRAINT ck_book_dates CHECK (dateTo > dateFrom)
    }
    PCTFree 5
    PCTUSED 15
    TABLESPACE CS342

/
