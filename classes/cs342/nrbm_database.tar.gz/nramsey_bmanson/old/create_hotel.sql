-- Good practice for PL/SQL syntax
-- Creates table for hotel
CREATE TABLE hotel (
        hNo number(5) primary key NOT NULL, 
        hName varchar(20) DEFAULT 'Marriot',
        city varchar(15) DEFAULT 'Las Vegas'
    )
    PCTFree 5
    PCTUSED 15
    TABLESPACE CS342
/
