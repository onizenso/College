create table bmanson(
    ID      number(5),
    name    varchar2(25)    default 'John Doe',
    address varchar2(100)
)
constraint pk_bmanson primary key(ID)
;
