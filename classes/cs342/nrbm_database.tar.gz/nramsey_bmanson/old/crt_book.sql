CREATE TABLE book (
        gNo number(5) NOT NULL,
        hNo number(5) NOT NULL,
        rNo number(5) NOT NULL,
        dateFrom Date NOT NULL,
        dateTo Date NOT NULL,
        CONSTRAINT pk_book PRIMARY KEY(gNo, hNo, rNo),
        CONSTRAINT fk_book book_guest FOREIGN KEY(gNo) REFERENCES guest(gNo),
        CONSTRAINT fk_book book_hotel FOREIGN KEY(hNo) REFERENCES guest(hNo),
        CONSTRAINT fk_book book_room  FOREIGN KEY(rNo) REFERENCES guest(rNo),
        CONSTRAINT ck_book_dates CHECK( dateTo > dateFrom )
    )
    PCTFree 5
    PCTUSED 15
    TABLESPACE CS342
/
