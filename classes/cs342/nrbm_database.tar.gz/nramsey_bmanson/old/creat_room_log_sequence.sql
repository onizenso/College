-- Creates room log sequence and autoincrements,
-- Buffer next 3 numbers in the sequence at a time

CREATE SEQUENCE room_log_sequence
START WITH 1
INCREMENT BY 1
CACHE 3
/
