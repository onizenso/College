create table hotel{
    hNo number(5) primary key not null,
    hName varchar(20) default "Marriot",
    city varchar(15) default "Las Vegas"
    }

    PCTFree 5
    PCTUSED 15
    TABLESPACE CS342
/
